package pal;

import java.util.LinkedList;
import java.util.List;
import java.util.Objects;

public class Pack {
    public List<Node> nodes;
    public int[] nodesDegrees;

    public Pack() {
        this.nodes = new LinkedList<Node>();
    }

    public Pack(List<Node> nodes) {
        this.nodes = nodes;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Pack pack = (Pack) o;
        return Objects.equals(nodes, pack.nodes);
    }

    @Override
    public int hashCode() {
        return Objects.hash(nodes);
    }
}
